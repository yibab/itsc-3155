import py_compile


word = input("Enter: ")
if len(word) < 2:
    print("Your string is too short!")
else: print(word[0]+word[1]+word[-2]+word[-1])