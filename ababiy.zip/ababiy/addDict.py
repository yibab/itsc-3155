
dic1 = {'a': 100, 'b': 200, 'c': 300}
dic2 = {'a': 300, 'b': 200, 'd': 400}
for x in dic1:
    if x in dic2:
        s = dic2[x]
        z = dic1[x]
        dic1[x] = s + z
    else:
        pass
    
        
print(dic1)


