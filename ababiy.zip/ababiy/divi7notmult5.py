def number(int1, int2):
    for x in range(int1, int2):
        if x%7 == 0 and x%5 != 0:
            print(x)

myNumber1 = input("Please enter first number:")
myNumber2 = input("Please enter second number:")
number(int(myNumber1), int(myNumber2))